package Amazon;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Iphone {

	@Test
	public void Amazon()
	{
		WebDriver oDriver = null;
		try
		{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Library\\chromedriver.exe");
			oDriver = new ChromeDriver();
			oDriver.manage().window().maximize();
			oDriver.navigate().to("https://www.amazon.in/");

			oDriver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Apple iPhone XR (64GB) - Yellow");
			oDriver.findElement(By.className("nav-input")).click();
			oDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
			WebDriverWait wait=new WebDriverWait(oDriver, 20);
			//Thread.sleep(2000);
			String A = oDriver.findElement(By.xpath("//span[@class='a-price-whole']")).getText();
			System.out.println("The Apple iPhone XR (64GB) - Yellow in Amazon: Rs"+A);

			oDriver.navigate().to("https://www.flipkart.com/");

			oDriver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
			oDriver.findElement(By.xpath("//input[@class='LM6RPg']")).sendKeys("Apple iPhone XR (Yellow, 64 GB)");
			oDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
			//Thread.sleep(2000);
			oDriver.findElement(By.className("vh79eN")).click();
			oDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
			//Thread.sleep(2000);
			String B = oDriver.findElement(By.xpath("//div[@class='_1vC4OE _2rQ-NK']")).getText();
			System.out.println("The Apple iPhone XR (64GB) - Yellow in Flipkart: Rs"+B);

			int i=0;
			{
				int A_ch=A.charAt(i);
				int B_ch=B.charAt(i);

				if(A_ch>B_ch)
				{
					System.out.println("Flipkart is cheaper with the price of Rs"+B);
				}
				else
				{
					System.out.println("Amazon is cheaper with the price of Rs"+A);
				}

			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			oDriver.quit();
			oDriver=null;
		}
	}
}