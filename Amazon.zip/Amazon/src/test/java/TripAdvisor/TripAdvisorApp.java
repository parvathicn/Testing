package TripAdvisor;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TripAdvisorApp {
	
	@Test
	public void TripAdvisor()
	{
		WebDriver oDriver = null;
		WebElement ele=null;
		try
		{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Library\\chromedriver.exe");
			oDriver = new ChromeDriver();
			oDriver.manage().window().maximize();
			oDriver.navigate().to("https://www.tripadvisor.in/");
			oDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
			//Initializing the Wait for 20 secs
			WebDriverWait wait=new WebDriverWait(oDriver, 20);
			//Wait for Search Icon
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Search']")));
			oDriver.findElement(By.xpath("//div[@title='Search']")).click();
			//Wait for Search Box
			ele= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='mainSearch']")));
			oDriver.findElement(By.xpath("//input[@id='mainSearch']")).sendKeys("Club Mahindra");
			oDriver.findElement(By.xpath("//input[@id='mainSearch']")).sendKeys(Keys.ENTER);
			
			//Wait for Results for Club Mahindra
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/span[contains(text(),'Club Mahindra Madikeri, Coorg')]")));
			oDriver.findElement(By.xpath("//div/span[contains(text(),'Club Mahindra Madikeri, Coorg')]")).click();
			//Scroll to element
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Save']")));
			oDriver.findElement(By.xpath("//div[@class='meta_inner']")).click();
	         //Scroll by		
			JavascriptExecutor js = (JavascriptExecutor) oDriver;
			js.executeScript("window.scrollBy(0,1000)");
			//Click Write a Review
			
			oDriver.findElement(By.xpath("//a[text()='Write a review']")).click();
			//Wait for Rating page
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='easyClear bigRatingParent']")));
			//	Mouse Over on rating
			 WebElement menuOption = oDriver.findElement(By.xpath("//div[@class='easyClear bigRatingParent']"));
		     //Mouse hover menuOption 'Music'
			 Actions actions = new Actions(oDriver);
		     actions.moveToElement(menuOption).perform();
		     System.out.println("Done Mouse hover on Ratings");
				oDriver.findElement(By.xpath("//div[@class='easyClear bigRatingParent']/span[@class='ui_bubble_rating fl bubble_50']")).click();
				oDriver.findElement(By.xpath("//input[@id='ReviewTitle']")).click();
				oDriver.findElement(By.xpath("//input[@id='ReviewTitle']")).sendKeys("Good");
				oDriver.findElement(By.xpath("//textarea[@id='ReviewText']")).click();
				oDriver.findElement(By.xpath("//textarea[@id='ReviewText']")).sendKeys("Good");
				oDriver.findElement(By.xpath("//service //label[contains(text(),'Service')]/following::select[@name='qid14']")).click();
				oDriver.findElement(By.xpath("//input[@id='noFraud']")).click();
				
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			oDriver.quit();
			oDriver=null;
		}
	}
}

